package com.example.guka.firebaseapp

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_sign_in.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private val TAG = "GUKATAG"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // Getting Current User and Firebase Reference
        val user = FirebaseAuth.getInstance().currentUser
        val db = FirebaseFirestore.getInstance()

        if (user != null) {

            val uid = user.uid

            // Create a reference to Firestore
            val reference = db.collection("users").document(uid)

            reference.get()
                .addOnSuccessListener { document ->
                    toast("GOT")
                    val username = document["username"].toString()
                    textViewEmail.text = username
                }
                .addOnFailureListener { exception ->
                    Log.d(TAG, "get failed with ", exception)
                }

        }





        // Users Button
        button_users.setOnClickListener{
            startActivity<UsersActivity>()
        }

        // Logging Out
        button_logout.setOnClickListener{

            FirebaseAuth.getInstance().signOut()
            startActivity<SignInActivity>()
        }
    }
}
